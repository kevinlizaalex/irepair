<?php
include('include/header.php');
require('stripe-php-master/init.php');
include('include/dbconnect.php');
$vaar = $_SESSION["s_rate"];
$selectLoanSql = "SELECT rate from tbl_repairdetails where id ='$vaar'";
echo "selectLoanSql";
$selectLoanResult = mysqli_query($con, $selectLoanSql);
$Row = mysqli_fetch_array($selectLoanResult);
$loadId = $Row['loan_amt'];
$payAmount = $loadId * 100;
$publishableKey = "pk_test_51K3Zq4SJlW41rTlc7WOcIBcz4Ly24cK2KlklLNCJzaWmztNOxRvKC0HhwyhGY3b8BnNBZeaLAAgPsVNeR6HSYmwS0093ftdJ4x";
$secretKey = "sk_test_51K3Zq4SJlW41rTlcpbgNsjRWmqk8k7MTYKtICvBAZBZ41l1lFftoe5MPW26tH7i7H7sZKQLQZZaJkPAlNm6ziCkg00OLdJzBmQ";
\Stripe\Stripe::setApiKey($secretKey);
