<?php
require('stripe-php-master/config.php');
include 'include/dbconnect.php';
if (isset($_POST['stripeToken'])) {
    \Stripe\Stripe::setVerifySslCerts(false);

    $token = $_POST['stripeToken'];

    $data = \Stripe\Charge::create(array(
        "amount" => "$payAmount",
        "currency" => "inr",
        "description" => "Thekkemury Finannciers Payment",
        "source" => $token,
    ));

    echo ("<script LANGUAGE='JavaScript'>
    window.location.href='userdashboard.php';
    </script>");
}
